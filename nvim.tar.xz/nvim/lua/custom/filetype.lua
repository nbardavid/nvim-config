-- ~/.config/nvim/lua/custom/filetype.lua

-- Associe les fichiers .tpp à la syntaxe C++
vim.filetype.add({
  extension = {
    tpp = "cpp",
  },
})
